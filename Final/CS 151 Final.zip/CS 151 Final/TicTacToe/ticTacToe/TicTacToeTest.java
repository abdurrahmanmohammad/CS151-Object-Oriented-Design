package ticTacToe;

public class TicTacToeTest {

	public static void main(String[] args) {
		/** AI testing done here along with TicTacToe */
		TicTacToe ticTacToe = new TicTacToe(); /** Create a new Tic Tac Toe game */
		ticTacToe.initiate(); /** Start the game */
	}
}
